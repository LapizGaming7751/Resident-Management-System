<html>
    <head>
        <title>Register new Resident</title>
    </head>
    <body>
        
    </body>
</html>