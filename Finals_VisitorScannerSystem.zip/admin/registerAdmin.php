<html>
    <head>
        <title>Register new Admin</title>
    </head>
    <body>
        
    </body>
</html>